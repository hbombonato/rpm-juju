"""Contains code common to more than one machine provider"""

"""Contains code specific to the various machine provider backends"""
